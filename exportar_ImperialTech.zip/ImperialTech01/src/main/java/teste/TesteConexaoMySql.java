package teste;

import modell.Conexao;

public class TesteConexaoMySql {

	public static void main(String[] args) {

			Conexao.obterConexao();

	}

}
